from http import HTTPStatus
from os import truncate
from django.shortcuts import get_list_or_404, get_object_or_404
from .models import Article, Comment
from .serializers import ArticleListSerializer, ArticleSerializer, CommentSerializer
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status

from articles import serializers
# api_view 데코레이터
# 반환할 Response 클래스
# ArticleListSerializer 

@api_view(['GET','POST'])
def article_list(request):
    if request.method == 'GET':
        # articles = Article.objects.all()
        # articles = get_list_or_404(Article)
        articles = get_list_or_404(Article.objects.order_by('-pk'))
        serializer = ArticleListSerializer(articles, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = ArticleSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            # return Response({'msg': '게시글 생성 성공'}) # 딕셔너리 형태로 주면 json으로 변환
            return Response(serializer.data, status.HTTP_201_CREATED)
        # return Response(serializer.errors) = raise_exception=True 의 역할 (상태코드X)
        # return Response(serializer.errors, status.HTTP_400_BAD_REQUEST) = raise_exception=True 의 역할 (상태코드까지)

@api_view(['GET','PUT','DELETE',])
def article_detail(request, article_pk):
    # article = Article.objects.get(pk=article_pk)
    article = get_object_or_404(Article, pk=article_pk) # 다 공통으로 pk필요

    if request.method == 'GET':
        serializer = ArticleSerializer(article)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = ArticleSerializer(instance=article, data=request.POST, partial=True) # 기존 데이터 / 바꿀 데이터 / 부분 데이터만 보내도 되는 옵션
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(serializer.data)
    
    elif request.method == 'DELETE':
        article.delete()
        result = {'delete':f'{article_pk}번 게시글 삭제'}
        return Response(result, status.HTTP_204_NO_CONTENT)

@api_view(['GET',])
def comment_list(request):
    comments = get_list_or_404(Comment)
    serializer = CommentSerializer(comments, many=True)
    return Response(serializer.data)


@api_view(['GET','PUT','DELETE'])
def comment_detail(request, comment_pk):
    comment = get_object_or_404(Comment,pk=comment_pk)
    if request.method == 'GET':
        serializer = CommentSerializer(comment)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = CommentSerializer(comment, data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(serializer.data)

    elif request.method == 'DELETE':
        comment.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(['POST',])
def comment_create(request, article_pk):
    # Article instance를 Comment의 외래키필드 article에 저장해야함 
    article = get_object_or_404(Article, pk=article_pk)
    serializer = CommentSerializer(data=request.data)
    if serializer.is_valid(raise_exception=True):
        serializer.save(article=article)                                    # 폼의 경우에는 commit=False 사용
        return Response(serializer.data, status=status.HTTP_201_CREATED)
