
from django.urls import path
from . import views

urlpatterns = [
    # 게시글 전체 조회 > api/v1/articles [GET]
    # 게시글 생성 >      api/v1/articles [POST]

    # 상세글 조회 >      api/v1/articles/<int:article_pk> [GET]
    # 상세글 삭제 >      api/v1/articles/<int:article_pk> [DELETE]
    # 상세글 수정 >      api/v1/articles/<int:article_pk> [PUSH]

    path('articles/', views.article_list),   # 조회 생성 같이
    path('articles/<int:article_pk>/', views.article_detail),

    # 댓글 전체조회 >    api/v1/comments [GET]
    # 댓글 상세조회 >    api/v1/comments/<int:comment_pk>  [GET]
    path('comments/', views.comment_list),
    # 댓글 생성 >        api/v1/articles/<int:article_pk>/comments/  [POST]
    path('comments/<int:comment_pk>/',views.comment_detail),
    # 댓글 삭제 >        api/v1/articles/<int:comment_pk>  [DELETE]
    # 댓글 수정 >        api/v1/articles/<int:comment_pk>  [PUT]
    path('articles/<int:article_pk>/comments/',views.comment_create),
]
